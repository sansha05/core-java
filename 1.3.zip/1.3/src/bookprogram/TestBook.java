package bookprogram;

public class TestBook {
	
	static Book[] createBooks(int n) {
		Book[] books = new Book[n];
		
		for(int i=0; i<n; i++) {
			books[i] = new Book();
		}
		
		return books;
	}
	
	
	static void showBooks(Book[] books) {
		System.out.println("Book Title              Price");
		for(int i=0; i<books.length; i++) {
			System.out.println(books[i].getTitle() + "            " + books[i].getPrice());
		}
	}
	

	public static void main(String[] args) {
		Book[] books = createBooks(2);
		books[0].setTitle("Java Programming");
		books[0].setPrice(230);
		books[1].setTitle("Let us C");
		books[1].setPrice(275);
		
		showBooks(books);
		
		
	}

}
