package com.statement_5_1;

public class StringHandling {

	public static void main(String[] args) {
		String str = "JAVA is simple";
		
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		
		String[] str_arr = str.split(" ");
		for(String s: str_arr) {
			System.out.print(s.charAt(0) + " ");
		}
		
		System.out.println();
		for(int i=str_arr.length-1; i>=0; i--) {
			System.out.print(str_arr[i] + " ");
		}
		
		StringBuilder txt = new StringBuilder("JAVA is simple");
		
		System.out.println(txt.reverse());
		System.out.println("Total Length is: "+str.length());
	}

}
