package com.statement_2_2;

public class Next13Number {

	public static void main(String[] args) {
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		
		for(int i=0; i<13 + 2; i++) {
			int temp=num1;
			num1=num2;
			num2=temp+num1;
			System.out.print(temp + " ");
		}

	}

}
