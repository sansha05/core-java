package com.statement_6_4;

import java.util.HashMap;

public class PhoneBook {
	HashMap<String, Integer> phonedir = new HashMap<String, Integer>();
	
	public void addPhoneNo(String name, Integer number) {
		phonedir.put(name, number);
	}

	public HashMap<String, Integer> getPhonedir() {
		return phonedir;
	}
	
	public int searchNumber(String name) {
		return phonedir.get(name);
	}

}
