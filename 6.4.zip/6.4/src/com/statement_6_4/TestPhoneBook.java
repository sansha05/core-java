package com.statement_6_4;

import java.util.Scanner;

public class TestPhoneBook {

	public static void main(String[] args) {
		PhoneBook pb = new PhoneBook();

		Scanner sc = new Scanner(System.in);
		String ch;
		
		do {
			System.out.println("a. Add new phone book entry");
			System.out.println("b. Search Phone Number");
			System.out.println("c. Quit");
			ch = sc.next();

			switch(ch) {
			case "a":
				System.out.println("Enter name and number to add to phone Book: ");
				String name = sc.next();
				int number = sc.nextInt();
				pb.addPhoneNo(name, number);
				break;
				
			case "b":
				System.out.println("Enter name to find number: ");
				String nm = sc.next();
				System.out.println(pb.searchNumber(nm)); 
				break;
			}

		} while(ch.equals("c") == false);
		
		System.out.println("program terminated!!!");
	}

}
