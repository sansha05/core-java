package com.statement_7_2;

public class FieldEmptyException extends Exception {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Field is empty, please enter all data agian";
	}
}
