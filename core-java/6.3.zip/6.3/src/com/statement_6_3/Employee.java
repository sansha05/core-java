package com.statement_6_3;

public class Employee {
	private int employeeNO;
	private String name;
	private String address;
	
	public int getEmployeeNO() {
		return employeeNO;
	}

	public void setEmployeeNO(int employeeNO) {
		this.employeeNO = employeeNO;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Employee(int employeeNO, String name, String address) {
		super();
		this.employeeNO = employeeNO;
		this.name = name;
		this.address = address;
	}
	
	public Employee() {

	}
	
	

}
