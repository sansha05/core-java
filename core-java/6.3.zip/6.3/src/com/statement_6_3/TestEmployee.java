package com.statement_6_3;

import java.util.LinkedList;
import java.util.ListIterator;

public class TestEmployee {
	
	static LinkedList<Employee> addInput() {
		LinkedList<Employee> emplist = new LinkedList<Employee>();
		Employee em1 = new Employee(23, "sandeep", "hirapur");
		Employee em2 = new Employee(24, "raja", "raipur");
		Employee em3 = new Employee(25, "jai", "bilaspur");
		Employee em4 = new Employee(26, "raghu", "bastar");
		
		emplist.add(em1);
		emplist.add(em2);
		emplist.add(em3);
		emplist.add(em4);
		
		return emplist;
	}
	
	static void display(Employee emp) {
		System.out.println(emp.getEmployeeNO());
		System.out.println(emp.getName());
		System.out.println(emp.getAddress());
		System.out.println();
	
	}

	public static void main(String[] args) {

		
		LinkedList<Employee> empList = addInput();
		ListIterator<Employee> empItr = empList.listIterator();
		
		
		Employee emp1 = empItr.next();
		Employee emp2 = empItr.next();
		
		display(emp1);
		display(emp2);
		
		display(empItr.previous());
		display(empItr.previous());
		
		
		
	}

}
