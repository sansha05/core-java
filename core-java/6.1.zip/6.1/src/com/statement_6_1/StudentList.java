package com.statement_6_1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentList {
	public static void main(String[] args) {
		ArrayList<String> a1 = new ArrayList<String>();
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number of students:");
		n = sc.nextInt();
		System.out.println("enter the student names:");
		for (int i = 0; i < n; i++) {
			a1.add(sc.next());
		}
		System.out.println("student list:");
		for (String a : a1) {
			System.out.println(a);

		}
		System.out.println("enter the name of the student to be searched:");
		String st = sc.next();
		int pos=-1;
		for(int i=0; i<a1.size(); i++) {
			if(a1.get(i).equals(st)) {
				pos=i;
				break;
			}
				
		}
		
		if(pos !=-1) {
			System.out.println("present at: " + pos);
		} else {
			System.out.println("name not available in the list");
		}
		
	}
}
