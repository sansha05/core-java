package com.statement_7_1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CopyFile {
	public static void main(String[] args) throws IOException {
		String source = args[0];
		String destination = args[1];

		File source_file = new File(source);
		File dest_file = new File(destination);
		FileReader fr = null;
		FileWriter fw = null;

		if (source_file.exists()) {
			fr = new FileReader(source_file);

			if (dest_file.createNewFile()) {
				fw = new FileWriter(dest_file);
				int i;
				while((i =fr.read()) != -1) {
					fw.write((char)i);
				}
				
				System.out.println("file copied successfully!!");
			} else {
				System.out.println("Whether you want to overwrite yes/no? ");
				Scanner sc = new Scanner(System.in);
				String choice = sc.next();
				if(choice.equals("yes")) {
					fw = new FileWriter(dest_file);
					int i;
					while((i = fr.read()) != -1) {
						fw.write((char)i);
					}
					System.out.println("file copied successfully!!");

				} else {
					System.out.println("file remain unchanged!!!!");
				}
			}
		} else {
			System.out.println("source file not exist!!!");
		}

		fr.close();
		fw.close();
	}
}