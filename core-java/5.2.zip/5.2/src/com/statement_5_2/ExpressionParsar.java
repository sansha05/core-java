package com.statement_5_2;

public class ExpressionParsar {

	public static void main(String[] args) {

		String txt = String.join("  ", args);
		String[] w = txt.split("\\\s");
		System.out.println(w.toString());

		for (String w1 : w) {
			System.out.println(w1);
			// System.out.println(" ");
		}

	}

}
