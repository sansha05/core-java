package com;

import java.util.Scanner;

public class ListEven {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter any number: ");
		int number = sc.nextInt();
		System.out.println("List of even numbers to " + number + " : ");
		for(int i=0; i<=number; i++) {
			if(i%2==0) {
				System.out.print(i + " ");
			}
		}
		
	}

}
