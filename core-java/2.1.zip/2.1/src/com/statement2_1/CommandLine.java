package com.statement2_1;

public class CommandLine {
	
	static boolean checkPalindrome(String str) {
		String reverse_str = "";
		int strLength = str.length()-1;
		while(strLength >= 0) {
			reverse_str += str.charAt(strLength);
			strLength--;
		}
		
		System.out.println(reverse_str);
		
		if (str.equals(reverse_str))
			return true;
		else
			return false;
	}
	
	public static void main(String[] args) {
		String str = args[0];
		
		System.out.println("length of " + str + " : " + str.length());
		System.out.println("uppercase of "+ str + " : " + str.toUpperCase());
		System.out.println("it is palindrome: " + checkPalindrome(str));
		
	}

}
