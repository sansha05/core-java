package com.statement_3_1;

public class TestInstrument {
	
	public static void main(String[] args) {
		Instrument[] instruments = new Instrument[10];
		instruments[0] = new Piano();
		instruments[1] = new Guitar();
		instruments[2] = new Flute();
		instruments[3] = new Piano();
		instruments[4] = new Flute();
		instruments[5] = new Guitar();
		instruments[6] = new Guitar();
		instruments[7] = new Flute();
		instruments[8] = new Guitar();
		instruments[9] = new Piano();
		
		for(Instrument instrument: instruments) {
			if (instrument instanceof Piano) {
				System.out.println("Piano");
			}
			if (instrument instanceof Guitar) {
				System.out.println("Guitar");
			}
			if (instrument instanceof Flute) {
				System.out.println("Flute");
			}
			instrument.play();
			System.out.println();
		}
	}

}
