package com.statement_3_1;

public class Piano extends Instrument {

	@Override
	void play() {
		System.out.println("Piano is playing tan tan tan tan");
	}

}
