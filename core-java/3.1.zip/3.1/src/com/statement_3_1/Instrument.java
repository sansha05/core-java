package com.statement_3_1;

public abstract class Instrument {
	abstract void play();
}
