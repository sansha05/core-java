package com.rectangle;

public class TestRectangle {

	public static void main(String[] args) {
		Rectangle rec1 = new Rectangle(5.7, 7);
		Rectangle rec2 = new Rectangle(6, 7);
		Rectangle rec3 = new Rectangle(45.4, 30);
		Rectangle rec4 = new Rectangle(23.1, 12);
		Rectangle rec5 = new Rectangle();
		rec5.setLength(33);
		rec5.setBreadth(23);
		
		rec1.calculateArea();
		rec2.calculateArea();
		rec3.calculateArea();
		rec4.calculateArea();
		rec5.calculateArea();
		
		rec1.displayInfo();
		rec2.displayInfo();
		rec3.displayInfo();
		rec4.displayInfo();
		rec5.displayInfo();
	}

}
