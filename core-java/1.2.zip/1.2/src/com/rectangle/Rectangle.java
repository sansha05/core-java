package com.rectangle;

public class Rectangle {
	
	private double length;
	private double breadth;
	private double result;
	
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	
	public Rectangle() {
		super();
		this.length = 0;
		this.breadth = 0;
	}
	
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getBreadth() {
		return breadth;
	}
	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	
	
	public void calculateArea() {
		result = length * breadth;
	}
	
	
	public void displayInfo() {
		System.out.println("length of rectangle: " + length);
		System.out.println("breadth of rectangle: " + breadth);
		System.out.println("area of rectangle: " + result + "\n");
	}
	

}
