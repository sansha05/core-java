package com.statement_3_2;

public interface MedicineInfo {
	public void displayLabel();
}
