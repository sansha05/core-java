package com.statement_3_2;

public class Syrup implements MedicineInfo {

	@Override
	public void displayLabel() {
		System.out.println("shake well before use");
	}

}
