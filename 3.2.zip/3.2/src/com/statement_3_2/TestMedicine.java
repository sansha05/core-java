package com.statement_3_2;

public class TestMedicine {

	public static void main(String[] args) {
		MedicineInfo[] medicine = new MedicineInfo[10];

		for (int i = 0; i < medicine.length; i++) {
			int random_no = (int) (Math.random() * 4);
			System.out.println(random_no);
			if (random_no == 1) {
				medicine[i] = new Tablet();
			} else if (random_no == 2) {
				medicine[i] = new Syrup();
			} else if (random_no == 3) {
				medicine[i] = new Ointment();
			} else if (random_no == 0) {
				medicine[i] = new Syrup();
			}
		}

		for (MedicineInfo medi : medicine) {
			medi.displayLabel();
			System.out.println();
		}

	}

}
