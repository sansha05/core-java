package com.statement_7_3;

import java.io.Serializable;
import java.util.HashMap;

public class Product implements Serializable {
	private HashMap<String, String> products = new HashMap<String, String>();
	
	public void addProducts(String key, String value) {
		products.put(key, value);
	}
	
	public void displayProducts() {
		System.out.println(products.toString());
	}
}