package com.mycompany.app;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.mycompany.dao.ProductManagementDAO;
import com.mycompany.domain.Products;

public class ProductManagementApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		ProductManagementDAO dao = new ProductManagementDAO();
		String ch = new String();
		Scanner sc = new Scanner(System.in);

		do {

			System.out.println(
					"A. View Products \nB. Add Product \nC. Update Product\nD. Delete Product\nE. Search Product\nF. Exit");
			System.out.println("======================");
			System.out.println("Enter an Option");
			System.out.println("======================");

			ch = sc.next();
			
			switch(ch) {
			case "A":
				List<Products> products = dao.getProducts();
				for(Products product: products) {
					System.out.println(product.getId());
					System.out.println(product.getProduct());
					System.out.println(product.getPrice());
					System.out.println();
				}
				System.out.println("--------------------");
				break;
			case "B":
				System.out.println("--------------------");
				System.out.println("Enter Product id");
				System.out.println("--------------------");
				String id = sc.next();
				System.out.println("--------------------");
				System.out.println("Enter Product Name");
				System.out.println("--------------------");
				String name = sc.next();
				System.out.println("--------------------");
				System.out.println("Enter Product Price");
				System.out.println("--------------------");
				double price = sc.nextDouble();
				Products product = new Products(id, name, price);
				dao.addProdct(product);
				System.out.println("Product add successfully!!\n");
				System.out.println("--------------------");
				break;
				
			case "C":
				System.out.println("--------------------");
				System.out.println("Enter Product id");
				System.out.println("--------------------");
				String idu = sc.next();
				System.out.println("--------------------");
				System.out.println("Enter new Product Name");
				System.out.println("--------------------");
				String nameu = sc.next();
				System.out.println("--------------------");
				System.out.println("Enter new Product Price");
				System.out.println("--------------------");
				double priceu = sc.nextDouble();
				Products productu = new Products(idu, nameu, priceu);
				
				dao.updateProduct(productu);
				System.out.println("product updated successfully!!");
				System.out.println("--------------------");
				break;
				
			case "D":
				System.out.println("--------------------");
				System.out.println("Enter Product id");
				System.out.println("--------------------");
				String idd = sc.next();
				dao.deleteProduct(idd);
				System.out.println("Product delete!!");
				System.out.println();
				System.out.println("--------------------");
				break;
				
			case "E":
				System.out.println("--------------------");
				System.out.println("Enter Product id");
				System.out.println("--------------------");
				String ids = sc.next();
				Products productfs = dao.searchProduct(ids);
				System.out.println(productfs.getProduct());
				System.out.println(productfs.getPrice());
				System.out.println("---------------------");
				break;
				
			default:
				System.out.println("Please Enter valid alphabat");
				System.out.println();
				break;
			}

		} while (ch.equals("F") == false);

	}

}
