package com.mycompany.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.dbutil.DBUtil;
import com.mycompany.domain.Products;

public class ProductManagementDAO {
	
	public List<Products> getProducts() throws ClassNotFoundException, SQLException {
		List<Products> products = new ArrayList<Products>();
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		Statement stmt = connection.createStatement();
		ResultSet rs = stmt.executeQuery("select * from product");
		
		while(rs.next()) {
			Products product = new Products();
			product.setId(rs.getString("id"));
			product.setProduct(rs.getString("product"));
			product.setPrice(rs.getDouble("price"));
			
			products.add(product);
		}
	
		dbUtil.closeConnection();
		
		
		return products;
		
	}
	
	public void addProdct(Products product) throws ClassNotFoundException, SQLException {
		String add_query = "insert into product (id, product, price) values (?, ?, ?)";
		
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		PreparedStatement stmt = connection.prepareStatement(add_query);
		stmt.setString(1, product.getId());
		stmt.setString(2, product.getProduct());
		stmt.setDouble(3, product.getPrice());
		
		stmt.execute();
		dbUtil.closeConnection();
		
	}
	
	
	public void updateProduct(Products product) throws SQLException, ClassNotFoundException {
//		
//		UPDATE table_name
//		SET column1 = value1, column2 = value2, ...
//		WHERE condition;
		
		String update_query = "update product set product = ?, price = ? where id = ?";
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		PreparedStatement stmt = connection.prepareStatement(update_query);
		stmt.setString(1, product.getProduct());
		stmt.setDouble(2, product.getPrice());
		stmt.setString(3, product.getId());
		
		stmt.execute();
		dbUtil.closeConnection();
	}
	
	public void deleteProduct(String id) throws SQLException, ClassNotFoundException {
		String delete_query = "delete from product where id = ?";
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		PreparedStatement stmt = connection.prepareStatement(delete_query);
		stmt.setString(1, id);
		stmt.execute();
		dbUtil.closeConnection();
		
	}
	
	public Products searchProduct(String id) throws SQLException, ClassNotFoundException {
		String search_query = "select * from product where id = ?";
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		PreparedStatement stmt = connection.prepareStatement(search_query);
		stmt.setString(1, id);
		ResultSet rs = stmt.executeQuery();
		Products product = new Products();
		if (rs.next()) {
			product.setId(rs.getString("id"));
			product.setProduct(rs.getString("product"));
			product.setPrice(rs.getDouble("price"));
		}
		
		dbUtil.closeConnection();
		
		return product;
		
	}
	
	

}
