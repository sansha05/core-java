package com.myapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.myapp.dbutil.DBUtil;
import com.myapp.pojo.Books;
import com.myapp.pojo.User;

public class BookDao {
	DBUtil dbutil = null;
	
	public List<Books> getBooks() throws ClassNotFoundException, SQLException {
		List<Books> books = new ArrayList<>();
		dbutil = new DBUtil();
		String query = "select * from books";
		Connection con = dbutil.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		
		while(rs.next()) {
			Books book = new Books();
			book.setBook_id(rs.getInt("book_id"));
			book.setBook_name(rs.getString("book_name"));
			book.setAuthor(rs.getString("author"));
			book.setPrice(rs.getInt("price"));
			books.add(book);
		}
		dbutil.closeConnection();
		return books;
	
	}
	
	
	public Books getBook(int book_id) throws ClassNotFoundException, SQLException {
		DBUtil dbutil = new DBUtil();
		Connection con = dbutil.getConnection();
		String find_query = "select * from books where book_id = ?";
		PreparedStatement stmt = con.prepareStatement(find_query);
		stmt.setInt(1, book_id);
		ResultSet rs = stmt.executeQuery();
		Books book = new Books();
		while(rs.next()) {
			book.setBook_id(rs.getInt("book_id"));
			book.setBook_name(rs.getString("book_name"));
			book.setAuthor(rs.getString("author"));
			book.setPrice(rs.getInt("price"));
		}
		
		return book;
		
		
	}
}
