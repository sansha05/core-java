package com.myapp.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.myapp.dbutil.DBUtil;
import com.myapp.pojo.User;


public class UserDao {
	

	public void addUser(User user) throws ClassNotFoundException, SQLException {
		DBUtil dbutil = new DBUtil();
		String add_query = "insert into users (first_name, address, email, user_name, password, registration_date) values (?,?,?,?,?,?)";
		Connection connection = dbutil.getConnection();
		PreparedStatement stmt = connection.prepareStatement(add_query);
		stmt.setString(1, user.getFirst_name());
		stmt.setString(2, user.getAddress());
		stmt.setString(3, user.getEmail());
		stmt.setString(4, user.getUser_name());
		stmt.setString(5, user.getPassword());
		stmt.setString(6, user.getRegistration_date());
		stmt.execute();
		dbutil.closeConnection();
	}

	public User getUser(String username, String password) throws ClassNotFoundException, SQLException {
		DBUtil dbutil = new DBUtil();
		Connection con = dbutil.getConnection();
		String find_query = "select * from users where user_name = ? and password = ?";
		PreparedStatement stmt = con.prepareStatement(find_query);
		stmt.setString(1, username);
		stmt.setString(2, password);
		ResultSet rs = stmt.executeQuery();
		User user = new User();
		while(rs.next()) {
			user.setFirst_name(rs.getString("first_name"));
			user.setAddress(rs.getString("address"));
			user.setEmail(rs.getString("email"));
			user.setUser_name(rs.getString("user_name"));
			user.setPassword(rs.getString("password"));
			user.setRegistration_date(rs.getString("registration_date"));
		}
		
		return user;
		
		
	}
	
	
	public void updatePassword(String username, String email, String password) throws SQLException, ClassNotFoundException {
//		
//		UPDATE table_name
//		SET column1 = value1, column2 = value2, ...
//		WHERE condition;
		
		String update_query = "update users set password = ? where user_name=? and email=?";
		DBUtil dbUtil = new DBUtil();
		Connection connection = dbUtil.getConnection();
		
		PreparedStatement stmt = connection.prepareStatement(update_query);
		stmt.setString(1, password);
		stmt.setString(2, username);
		stmt.setString(3, email);
		
		stmt.execute();
		dbUtil.closeConnection();
	}

}
