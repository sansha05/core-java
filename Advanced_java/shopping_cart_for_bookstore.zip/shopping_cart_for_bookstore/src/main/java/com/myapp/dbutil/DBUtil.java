package com.myapp.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private Connection connection = null;
	private String url = "jdbc:mysql://localhost:3306/productdb";
	private String username = "root";
	private String password = "1234asdf";

	public DBUtil() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
		this.connection = DriverManager.getConnection(url, username, password);

	}

	public Connection getConnection() {

		return this.connection;

	}
	
	public void closeConnection() throws SQLException {
		if(this.connection != null) {
			this.connection.close();
		}
	}

}
