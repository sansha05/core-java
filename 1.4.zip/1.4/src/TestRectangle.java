
public class TestRectangle {

	public static void main(String[] args) {
		Rectangle rec = new Rectangle();

		rec.setLength(19);
		rec.setwidth(5);

		rec.calculateArea();
		rec.calculatePerimeter();

		rec.displayInfo();
	}

}
