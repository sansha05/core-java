public class Rectangle {
	
	private double length;
	private double width;
	private double area;
	private double perimeter;
	
	public Rectangle(double length, double width) {
		super();
		this.length = length;
		this.width = width;
	}
	
	public Rectangle() {
		super();
		this.length = 1;
		this.width = 1;
	}
	
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		if (length > 0.0 && length < 20.0)
			this.length = length;
		else
			System.out.println("plese enter length between 0.1 and 20.0");
	}
	public double getwidth() {
		return width;
	}
	public void setwidth(double width) {
		if (width > 0.0 && length < 20.0)
			this.width = width;
		else
			System.out.println("please enter width between 0.1 and 20.0");
	}
	
	
	public void calculateArea() {
		area = length * width;
	}
	
	public void calculatePerimeter() {
		perimeter =2*(length+width);
	}
	
	
	public void displayInfo() {
		System.out.println("length of rectangle: " + length);
		System.out.println("width of rectangle: " + width);
		System.out.println("area of rectangle: " + area + "\n");
		System.out.println("perimeter of rectangle: " + perimeter);
	}
	

}
